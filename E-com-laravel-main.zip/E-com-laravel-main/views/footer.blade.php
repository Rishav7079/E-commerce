<div style="clear:both;" class="panel panel-default">
  


<div class="panel-body">
 
   
<p style="color:blue;text-align:center;">Copyright &copy; 2021 PappuPajer</p>
</div>
<div class="panel-footer">
  
 <p style="color:blue;text-align:center;"> Designed by : @Partusha</p>
</div>
</div> 

  
